<footer class="footer-abajo col-12 mt-5">
        <h3>Contáctanos</h3>
        <p>Nuestro Email: <a href="mailto:graficoquill@gmail.com?subject=Para mejorar la página:))" class="text-white">graficoquill@gmail.com</a></p>
        <p>© 2024, Gráfico Guill</p>
    </footer>