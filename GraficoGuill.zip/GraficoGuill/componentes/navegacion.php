<?php
$uri = $_SERVER['REQUEST_URI'];
if (strpos($uri, 'paginas/mision.php') !== false || strpos($uri, 'paginas/vision.php') !== false || strpos($uri, 'paginas/acercaDe.php') !== false) {
    $inicio = '../index.php';
    $mision = '../paginas/mision.php';
    $vision = '../paginas/vision.php';
    $acercaDe = '../paginas/acercaDe.php';
} else {
    $inicio = './index.php';
    $mision = 'paginas/mision.php';
    $vision = 'paginas/vision.php';
    $acercaDe = 'paginas/acercaDe.php';
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $inicio; ?>">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $mision; ?>">Misión</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $vision; ?>">Visión</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo $acercaDe; ?>">Acerca De</a>
            </li>
        </ul>
    </div>
</nav>
