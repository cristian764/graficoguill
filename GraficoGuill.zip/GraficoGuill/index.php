<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfico Guill</title>

    <meta name="description" content="Esta es una página públicitaria de nuestra marca llamada Gráfico Guill, donde nuestra innovación son plumas amigables con el medio ambiente, a través de cartuchos y plumas que usan los mismos para poder reutilizar. Existen muchos colores para los cartuchos, para que plasmes todo lo que quieras!" />
    <meta name="keywords" content="Plumas Recargables, Guill, Plumas ecoamigables, Plumas con cartuchos" />
    <meta name="copyright" content="© 2024, Gráfico Guill">

    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

</head>
<body>
    <header>
        <img src="img/logo.png" alt="Logo de la Empresa">
        <h1>Grafico Guill</h1>
    </header>

    <?php require("componentes/navegacion.php") ?>

    <div class="col-9 mx-auto">
        <div class="card mb-3">
            <h2 class="text-center">Quill Style Pro</h2>
            <img src="img/pro.png" alt="Imagen de la pluma recargable" class="card-img-top">
            <div class="card-body">
                <h3 class="text-center">$300</h3>
                <p>Una pluma recargable es un instrumento de escritura que utiliza un cartucho de tinta rellenable en lugar de cartuchos desechables. Está diseñada para ser una alternativa más sostenible a las plumas de un solo uso, ya que permite rellenarla con tinta una vez que se agota, reduciendo así la generación de residuos. Estas plumas suelen estar fabricadas con materiales respetuosos con el medio ambiente, como plásticos reciclados o biodegradables, y están diseñadas para tener una larga vida útil.</p>
            </div>
        </div>

        <div class="card mb-3">
            <h2 class="text-center">Quill One Economic</h2>
            <img src="img/economic.png" alt="Imagen de la pluma recargable" class="card-img-top">
            <div class="card-body">
                <h3 class="text-center">$100</h3>
                <p>La pluma Guill One Economic es una pluma de cartucho que se puede recargar. Estas plumas se llaman plumas estilográficas y cuentan con una punta fina.</p>
            </div>
        </div>

        <div class="card mb-3">
            <h2 class="text-center">Paquete De 10 Cartuchos</h2>
            <img src="img/cartuchos1.png" alt="Imagen de la pluma recargable" class="card-img-top">
            <div class="card-body">
                <h3 class="text-center">$100</h3>
                <p>Estos son un paquete de 10 cartuchos. Cada cartucho tiene una capacidad de 1.45 mililitros de tinta. Estos cartuchos vienen en diferentes colores, incluyendo los colores clásicos como azul, negro y rojo.</p>
            </div>
        </div>

        <div class="card mb-3">
            <h2 class="text-center">Paquete De 35 Cartuchos</h2>
            <img src="img/cartuchos2.png" alt="Imagen de la pluma recargable" class="card-img-top">
            <div class="card-body">
                <h3 class="text-center">$300</h3>
                <p>Estos son un paquete de 35 cartuchos. Cada cartucho tiene una capacidad de 1.45 mililitros de tinta. Estos cartuchos vienen en diferentes colores, incluyendo los colores clásicos como azul, negro y rojo.</p>
            </div>
        </div>

    </div>

    <footer class="bg-dark text-white text-center py-3 mt-auto" style="bottom: 0; padding: 10px 20px;">
        <h3>Contáctanos</h3>
        <p style="display: block; margin-bottom: 0;">Nuestro Email: <a href="mailto:graficoquill@gmail.com?subject=Para mejorar la página:))" class="text-white">graficoquill@gmail.com</a></p>
        <p style="margin-bottom: 0;">© 2024, Gráfico Guill</p>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    
</body>
</html>
